/* Run: Java$ ./bin/compile.sh && ./bin/Test.sh */
import java.io.IOException;
import tests.*;

public class Test {
  public static void main(String[] args) throws IOException, InterruptedException, Exception {
	  BaseTest grovepiTest = new BaseTest();
  }
}
