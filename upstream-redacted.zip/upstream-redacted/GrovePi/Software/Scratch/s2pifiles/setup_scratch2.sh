sudo cp extensions.json /usr/lib/scratch2/scratch_extensions/extensions.json
sudo cp piGrovePiExtension.js /usr/lib/scratch2/scratch_extensions/piGrovePiExtension.js
sudo cp grovepi.html /usr/lib/scratch2/scratch_extensions/grovepi.html
sudo cp -u grovepi.png /usr/lib/scratch2/medialibrarythumbnails/grovepi.png
pip install scratchpy




