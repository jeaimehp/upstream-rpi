sudo pkill -f GrovePiScratch.py
sudo pkill -f wstosgh.py
python /home/pi/Dexter/GrovePi/Software/Scratch/GrovePiScratch.py &
python /home/pi/Dexter/GrovePi/Software/Scratch/wstosgh.py &
/usr/bin/scratch2

