﻿namespace GrovePi
{
    public enum PinMode
    {
        Input = 0,
        Output = 1
    }
}