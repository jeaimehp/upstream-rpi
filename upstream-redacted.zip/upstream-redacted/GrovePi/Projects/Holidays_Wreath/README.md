This folder contains the code to create a smart Holidays wreath, using a string of holiday lights from yesteryear.
The wreath lights will turn on when it's dark and wait for sunrise to turn off.
The lights will blink whenever a movement is detected, whether it's day or not.

Use:
- the PIR sensor on port D8, 
- the light sensor on port A0 
- and the relay on port D2

Write-up with explanations can be found here:
http://www.dexterindustries.com/projects/holiday-wreath/
